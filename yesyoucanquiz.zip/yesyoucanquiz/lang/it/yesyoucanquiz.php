<?php
// Italian language file for YesYouCanQuiz

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'YesYouCanQuiz';
$string['publicuserid'] = 'ID utente pubblico';
$string['publicuserid_desc'] = 'Seleziona l\'account utente che verrà utilizzato per i tentativi di quiz degli ospiti.';
$string['settings'] = 'Impostazioni di YesYouCanQuiz';
