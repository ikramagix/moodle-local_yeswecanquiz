<?php
// Spanish language file for YesYouCanQuiz

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'YesYouCanQuiz';
$string['publicuserid'] = 'ID de usuario público';
$string['publicuserid_desc'] = 'Seleccione la cuenta de usuario que se utilizará para intentos de cuestionario de invitados.';
$string['settings'] = 'Configuración de YesYouCanQuiz';
