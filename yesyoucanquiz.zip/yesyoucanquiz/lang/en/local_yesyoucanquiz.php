<?php
// English language file for YesYouCanQuiz

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'YesYouCanQuiz';
$string['publicuserid'] = 'Public User ID';
$string['publicuserid_desc'] = 'Select the user account that will be used for guest quiz attempts.';
$string['settings'] = 'YesYouCanQuiz Settings';
