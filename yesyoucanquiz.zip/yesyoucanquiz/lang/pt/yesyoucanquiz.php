<?php
// Portuguese language file for YesYouCanQuiz

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'YesYouCanQuiz';
$string['publicuserid'] = 'ID de usuário público';
$string['publicuserid_desc'] = 'Selecione a conta de usuário que será usada para tentativas de questionário de convidados.';
$string['settings'] = 'Configurações do YesYouCanQuiz';
