<?php
// German language file for YesYouCanQuiz

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'YesYouCanQuiz';
$string['publicuserid'] = 'Öffentliche Benutzer-ID';
$string['publicuserid_desc'] = 'Wählen Sie das Benutzerkonto aus, das für Quizversuche von Gästen verwendet wird.';
$string['settings'] = 'YesYouCanQuiz-Einstellungen';