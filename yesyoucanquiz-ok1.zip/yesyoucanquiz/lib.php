<?php
defined('MOODLE_INTERNAL') || die();

/**
 * Attempt to auto-login visitors as the public user on quiz pages.
 */
function yesyoucanquiz_auto_login() {
    global $USER, $DB, $SCRIPT;
    
    // Only trigger on quiz view or attempt pages.
    if (strpos($SCRIPT, '/mod/quiz/view.php') === false && strpos($SCRIPT, '/mod/quiz/attempt.php') === false) {
        return;
    }

    // If already logged in (and not guest) then do nothing.
    if (isloggedin() && !isguestuser()) {
        return;
    }

    // Get public user ID from plugin settings.
    $publicuserid = get_config('local_yesyoucanquiz', 'publicuserid');
    if ($publicuserid) {
        $publicuser = $DB->get_record('user', array('id' => $publicuserid, 'deleted' => 0, 'suspended' => 0));
        if ($publicuser) {
            // Complete login as the public user.
            complete_user_login($publicuser);
            // Force session data to be written.
            session_write_close();
            // Redirect to the current URL to refresh the session.
            $url = new moodle_url($SCRIPT, $_GET);
            redirect($url);
        }
    }
}

/**
 * Attempt to trigger auto-login earlier if Moodle calls this hook.
 * (Note: This hook may not be available in all Moodle versions.)
 */
function local_yesyoucanquiz_before_http_headers() {
    yesyoucanquiz_auto_login();
}

/**
 * Fallback hook – triggered when Moodle builds the navigation.
 */
function yesyoucanquiz_extend_navigation(global_navigation $navigation) {
    yesyoucanquiz_auto_login();
}
