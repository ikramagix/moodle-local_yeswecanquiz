YesYouCanQuiz - Allow guests to take quizzes
========================================

Description:
------------
This Moodle plugin helps you assign unauthenticated users to a 
"public" user account when attempting quizzes.

Installation:
-------------
1. Upload the "YesYouCanQuiz" folder to /local/ in your Moodle directory.
2. Go to Site Administration → Plugins → Local Plugins → Auto Public User.
3. Enter the User ID of the public user.
4. Save changes.
5. Test as an unauthenticated user.

Version: 1.1
Author: @ikramagix
