<?php
defined('MOODLE_INTERNAL') || die();

/**
 * Controls the session for YesYouCanQuiz.
 *
 * - When the current page is under /mod/quiz/ (view or attempt), if the user is not logged in or is a guest,
 *   log them in as the public user.
 * - When the current page is NOT under /mod/quiz/, if the user is logged in as the public user,
 *   log them out.
 */
function yesyoucanquiz_session_control() {
    global $USER, $DB, $SCRIPT, $CFG;

    // Get public user ID from plugin settings.
    $publicuserid = get_config('local_yesyoucanquiz', 'publicuserid');
    if (!$publicuserid) {
        return;
    }
    
    // Check if the current script is a quiz page.
    if (strpos($SCRIPT, '/mod/quiz/') !== false) {
        // On a quiz page: if not logged in or logged in as guest, then auto-login as public user.
        if (!isloggedin() || isguestuser()) {
            $publicuser = $DB->get_record('user', array('id' => $publicuserid, 'deleted' => 0, 'suspended' => 0));
            if ($publicuser) {
                complete_user_login($publicuser);
                session_write_close();
                // Redirect to refresh the session.
                $url = new moodle_url($SCRIPT, $_GET);
                redirect($url);
            }
        }
    } else {
        // Outside a quiz page: if logged in as the public user, then log them out.
        if (isloggedin() && !isguestuser() && $USER->id == $publicuserid) {
            // Use require_logout() instead of complete_user_logout() to properly log out.
            require_logout();
            // Redirect to refresh the session.
            $url = new moodle_url($SCRIPT, $_GET);
            redirect($url);
        }
    }
}

/**
 * Hook callback: attempt to trigger session control earlier if Moodle calls this hook.
 * (Note: This hook may not be available in all Moodle versions.)
 */
function local_yesyoucanquiz_before_http_headers() {
    yesyoucanquiz_session_control();
}

/**
 * Fallback hook – triggered when Moodle builds the navigation.
 */
function yesyoucanquiz_extend_navigation(global_navigation $navigation) {
    yesyoucanquiz_session_control();
}
